﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Net;
using System.Net.Sockets;

namespace MarioandLuigiV2
{
    public partial class Form1 : Form
    {
        private SerialPort port;
        string order;
        int moneysize;
        int moneyextra;
        string Total;
        //int  DineIn;
        //int Takeaway;
        WebSocket ws;
        ConnectForm cf;
        bool good = true;

        public Form1(string BoxLocalIP, string BoxLocalPort, string BoxRemotIP, string BoxRemotePort)
        {
            InitializeComponent();
            port = new SerialPort("COM3", 9600);
            ws = new WebSocket();
            ws.connect(BoxLocalIP,  BoxLocalPort,  BoxRemotIP,  BoxRemotePort);

        }

                   
        
        private void button1_Click(object sender, EventArgs e)
        {
            string Selection;
            Selection = Convert.ToString(lbFood.SelectedItem);


            {
                while (lbFood.SelectedItems.Count > 0) 
                {
                    tbCart.Items.Add("" + " - " + Selection);
                    lbFood.Items.Remove(Selection);
                } 

            }


            ///// ANotherWay
            //{
            //    string selection;
            //    if (lbFood.SelectedIndex != -1)
            //    {
            //        selection = lbFood.SelectedItem.ToString();
            //        tbCart.Text = tbCart.Text + "," + selection;
            //    }



        }

        ////public string Getunfo()
        ////{
        ////    int quantity = Convert.ToInt32(numericUpDown1.Value);
        ////    return "order type:" + order + tbCart.Text + "size:" + Size + "quantity:" + quantity  + "ExtraChicken";
        ////}
        /// I tried the Get Info way but it  didnt work
        private void button2_Click(object sender, EventArgs e)
        {
            timerListBox.Start();

            string finalOrder = "";

            if (!rbnDineIn.Checked && !rbnTakeAway.Checked)
            {
                good = false;
                MessageBox.Show("Please choose where do you want to eat");
            }
            else if (rbnDineIn.Checked)
            {
                order = "Dine in";
                
                
            }
            else if (rbnTakeAway.Checked)
            {
                order = "Take away";
            }
            
            string size;
            if (!rbnSmall.Checked && !rbnMedium.Checked && !rbnLarge.Checked)
            {
                good = false;
                MessageBox.Show("Please select a size");
            }
            if (rbnSmall.Checked)
            {
                
                size = "Small";
                moneysize = Convert.ToInt32(5.00);
            }
            else if (rbnMedium.Checked)
            {
                size = "Medium";
                moneysize= Convert.ToInt32(8.00);
            }
            else
            {
                size = "Larg";
                moneysize= Convert.ToInt32(10.00);

            }
            bool extracheese = cbExtracheese.Checked;
            bool extramushrooms = cbExrtamushrooms.Checked;
            bool extrachicken = cbChicken.Checked;

            int quantity = Convert.ToInt32(numericUpDown1.Value);

            if (good)
            {
                if (cbChicken.Checked)
                {

                    moneyextra = 1;
                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;

                    finalOrder = " order type: " + order + " " + getItems() + "  " + " size:" + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraChicken";
                    MessageBox.Show(finalOrder);



                }
                else if (cbExrtamushrooms.Checked)
                {
                    moneyextra = 1;
                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order + " " + getItems() + "  " + " size:" + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraMushrooms";
                    MessageBox.Show(finalOrder);


                }
                else if (cbExtracheese.Checked)
                {
                    moneyextra = 1;

                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order + " " + getItems() + "  " + "size: " + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraCheese";
                    MessageBox.Show(finalOrder);


                }
                else if (cbChicken.Checked && cbExrtamushrooms.Checked)
                {
                    moneyextra = 2;

                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order + " " + getItems() + "  " + " size:" + " " + size + "  " + " quantity:" + quantity + "  " + "ExtraChicken and ExtraMushrooms";
                    MessageBox.Show(finalOrder);

                }
                else if (cbExrtamushrooms.Checked && cbExtracheese.Checked)
                {
                    moneyextra = 2;

                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order + " " + getItems() + "  " + " size:" + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraCheese and ExtraMushrooms";
                    MessageBox.Show(finalOrder);


                }
                else if (cbExtracheese.Checked && cbChicken.Checked)
                {
                    moneyextra = 2;
                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order.ToString() + " " + getItems() + "  " + "size: " + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraChicken and ExtraCheese";
                    MessageBox.Show(finalOrder);

                }
                else if (cbChicken.Checked && cbExrtamushrooms.Checked && cbExtracheese.Checked)

                {
                    moneyextra = 3;
                    Total = Convert.ToString(moneyextra + moneysize * numericUpDown1.Value);
                    lblTotal.Text = "€" + Total;
                    finalOrder = " order type: " + order + " " + getItems() + "  " + "size: " + " " + size + "  " + " quantity: " + quantity + "  " + "ExtraChicken and ExtraMushrooms and ExtraCheese";
                    MessageBox.Show(finalOrder);

                }
                else
                {
                    moneyextra = 0;
                    finalOrder = "order type: " + order + " " + getItems() + "size: " + size + " " + "quantity: " + quantity;
                    MessageBox.Show(finalOrder);
                    Total = Convert.ToString(moneyextra + moneysize);
                    lblTotal.Text = "€" + Total;


                }
                //string msg;
                //msg = Convert.ToString(tbCart.Text);

                ws.sendMsg(finalOrder);
                //ws.sendMsg(tbCart.Text);
                tbCart.Text = "";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            port.Open();
           // ws.GetLocalIP();
           // timerListBox.Start();
            /*textBoxLocalIP.Text = ws.GetLocalIP()*/;
            timerListBox.Start();
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            port.Close();
        }



        private void btnRead_Click(object sender, EventArgs e)
        {
            int counter = 0;
            counter++;
            if (port.BytesToRead > 0)
            {
               
                string line = port.ReadLine();
                MessageBox.Show(line);
            }
        }
        //private void timerListBox_Tick(object sender, EventArgs e)
        //{
        //    foreach (var item in ws.messages)
        //    {
        //        MessageBox.Show(item);
        //    }
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            lbFood.Items.Clear();
            tbCart.Items.Clear();
           // lbFood.Items.Add("Beef" + "" + "Chicken" + "" + "Mushrooms" + "" + "Bacon" + "" + "Pepperoni" + "" + "Onions");
            string str = "Beef,Chicken,Mushrooms,Bacon,Pepperoni,Onions";
            string[] values = str.Split(',');

            foreach (string value in values)
            {
                if (value.Trim() == "")
                    continue;
                lbFood.Items.Add(value.Trim());
            }



        }

        private string getItems()
        {
            string text = "";
            foreach (var item in tbCart.Items)
            {
                text += item.ToString() + ""; // /n to print each item on new line or you omit /n to print text on same line
            }
            return text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            //ws.connect(textBoxLocalIP.Text, textBoxLocalPort.Text, textBoxRemotIP.Text, textBoxRemotePort.Text);
            //MessageBox.Show("Connection has been established. Now you can start sending messages. ");
        }

        private void buttonMessage_Click(object sender, EventArgs e)
        {
            //ws.sendMsg(textBoxMessage.Text);
            //textBoxMessage.Text = "";
        }
    }    
}
 