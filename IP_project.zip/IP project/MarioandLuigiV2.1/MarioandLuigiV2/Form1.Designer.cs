﻿namespace MarioandLuigiV2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbFood = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rbnDineIn = new System.Windows.Forms.RadioButton();
            this.rbnTakeAway = new System.Windows.Forms.RadioButton();
            this.rbnSmall = new System.Windows.Forms.RadioButton();
            this.rbnMedium = new System.Windows.Forms.RadioButton();
            this.rbnLarge = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbExtracheese = new System.Windows.Forms.CheckBox();
            this.cbExrtamushrooms = new System.Windows.Forms.CheckBox();
            this.cbChicken = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnRead = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.timerListBox = new System.Windows.Forms.Timer(this.components);
            this.tbCart = new System.Windows.Forms.ListBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbFood
            // 
            this.lbFood.FormattingEnabled = true;
            this.lbFood.Items.AddRange(new object[] {
            "Beef",
            "Chicken ",
            "Mushrooms",
            "Bacon",
            "Pepperoni",
            "Onions"});
            this.lbFood.Location = new System.Drawing.Point(46, 126);
            this.lbFood.Margin = new System.Windows.Forms.Padding(2);
            this.lbFood.Name = "lbFood";
            this.lbFood.Size = new System.Drawing.Size(163, 56);
            this.lbFood.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(232, 139);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 31);
            this.button1.TabIndex = 1;
            this.button1.Text = "Add to Pizza";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbnDineIn
            // 
            this.rbnDineIn.AutoSize = true;
            this.rbnDineIn.Location = new System.Drawing.Point(29, 23);
            this.rbnDineIn.Margin = new System.Windows.Forms.Padding(2);
            this.rbnDineIn.Name = "rbnDineIn";
            this.rbnDineIn.Size = new System.Drawing.Size(74, 20);
            this.rbnDineIn.TabIndex = 3;
            this.rbnDineIn.TabStop = true;
            this.rbnDineIn.Text = "Dine in";
            this.rbnDineIn.UseVisualStyleBackColor = true;
            // 
            // rbnTakeAway
            // 
            this.rbnTakeAway.AutoSize = true;
            this.rbnTakeAway.Location = new System.Drawing.Point(107, 23);
            this.rbnTakeAway.Margin = new System.Windows.Forms.Padding(2);
            this.rbnTakeAway.Name = "rbnTakeAway";
            this.rbnTakeAway.Size = new System.Drawing.Size(103, 20);
            this.rbnTakeAway.TabIndex = 4;
            this.rbnTakeAway.TabStop = true;
            this.rbnTakeAway.Text = "Take Away";
            this.rbnTakeAway.UseVisualStyleBackColor = true;
            // 
            // rbnSmall
            // 
            this.rbnSmall.AutoSize = true;
            this.rbnSmall.Location = new System.Drawing.Point(21, 29);
            this.rbnSmall.Margin = new System.Windows.Forms.Padding(2);
            this.rbnSmall.Name = "rbnSmall";
            this.rbnSmall.Size = new System.Drawing.Size(69, 20);
            this.rbnSmall.TabIndex = 6;
            this.rbnSmall.TabStop = true;
            this.rbnSmall.Text = "Small ";
            this.rbnSmall.UseVisualStyleBackColor = true;
            // 
            // rbnMedium
            // 
            this.rbnMedium.AutoSize = true;
            this.rbnMedium.Location = new System.Drawing.Point(94, 29);
            this.rbnMedium.Margin = new System.Windows.Forms.Padding(2);
            this.rbnMedium.Name = "rbnMedium";
            this.rbnMedium.Size = new System.Drawing.Size(80, 20);
            this.rbnMedium.TabIndex = 7;
            this.rbnMedium.TabStop = true;
            this.rbnMedium.Text = "Medium";
            this.rbnMedium.UseVisualStyleBackColor = true;
            // 
            // rbnLarge
            // 
            this.rbnLarge.AutoSize = true;
            this.rbnLarge.ForeColor = System.Drawing.Color.Black;
            this.rbnLarge.Location = new System.Drawing.Point(175, 29);
            this.rbnLarge.Margin = new System.Windows.Forms.Padding(2);
            this.rbnLarge.Name = "rbnLarge";
            this.rbnLarge.Size = new System.Drawing.Size(66, 20);
            this.rbnLarge.TabIndex = 8;
            this.rbnLarge.TabStop = true;
            this.rbnLarge.Text = "Large";
            this.rbnLarge.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rbnDineIn);
            this.groupBox1.Controls.Add(this.rbnTakeAway);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(35, 37);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(383, 65);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Order for: ";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DimGray;
            this.groupBox2.Controls.Add(this.rbnMedium);
            this.groupBox2.Controls.Add(this.rbnSmall);
            this.groupBox2.Controls.Add(this.rbnLarge);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(35, 201);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(245, 65);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Size:";
            // 
            // cbExtracheese
            // 
            this.cbExtracheese.AutoSize = true;
            this.cbExtracheese.BackColor = System.Drawing.Color.Transparent;
            this.cbExtracheese.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbExtracheese.Location = new System.Drawing.Point(50, 270);
            this.cbExtracheese.Margin = new System.Windows.Forms.Padding(2);
            this.cbExtracheese.Name = "cbExtracheese";
            this.cbExtracheese.Size = new System.Drawing.Size(111, 19);
            this.cbExtracheese.TabIndex = 13;
            this.cbExtracheese.Text = "Extra Cheese";
            this.cbExtracheese.UseVisualStyleBackColor = false;
            // 
            // cbExrtamushrooms
            // 
            this.cbExrtamushrooms.AutoSize = true;
            this.cbExrtamushrooms.BackColor = System.Drawing.Color.Transparent;
            this.cbExrtamushrooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbExrtamushrooms.Location = new System.Drawing.Point(50, 289);
            this.cbExrtamushrooms.Margin = new System.Windows.Forms.Padding(2);
            this.cbExrtamushrooms.Name = "cbExrtamushrooms";
            this.cbExrtamushrooms.Size = new System.Drawing.Size(138, 19);
            this.cbExrtamushrooms.TabIndex = 14;
            this.cbExrtamushrooms.Text = "Extra Mushrooms";
            this.cbExrtamushrooms.UseVisualStyleBackColor = false;
            // 
            // cbChicken
            // 
            this.cbChicken.AutoSize = true;
            this.cbChicken.BackColor = System.Drawing.Color.Transparent;
            this.cbChicken.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbChicken.Location = new System.Drawing.Point(50, 312);
            this.cbChicken.Margin = new System.Windows.Forms.Padding(2);
            this.cbChicken.Name = "cbChicken";
            this.cbChicken.Size = new System.Drawing.Size(114, 19);
            this.cbChicken.TabIndex = 15;
            this.cbChicken.Text = "Extra Chicken";
            this.cbChicken.UseVisualStyleBackColor = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(42, 356);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(119, 20);
            this.numericUpDown1.TabIndex = 16;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 338);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Quantity:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 104);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Create Your Very Own Pizza:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(479, 268);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 60);
            this.button2.TabIndex = 19;
            this.button2.Text = "Send to the Kitchen";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Andalus", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(194, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(275, 33);
            this.label3.TabIndex = 20;
            this.label3.Text = "Welcome to Pasta Solutions";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(505, 356);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(12, 15);
            this.lblTotal.TabIndex = 21;
            this.lblTotal.Text = "-";
            // 
            // btnRead
            // 
            this.btnRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRead.Location = new System.Drawing.Point(524, 57);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(91, 23);
            this.btnRead.TabIndex = 22;
            this.btnRead.Text = "Read MSG";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(412, 356);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Total Price:";
            // 
            // timerListBox
            // 
            this.timerListBox.Interval = 1000;
            // 
            // tbCart
            // 
            this.tbCart.FormattingEnabled = true;
            this.tbCart.Items.AddRange(new object[] {
            "Your Pizza Includes: "});
            this.tbCart.Location = new System.Drawing.Point(415, 126);
            this.tbCart.Name = "tbCart";
            this.tbCart.Size = new System.Drawing.Size(222, 69);
            this.tbCart.TabIndex = 24;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(524, 97);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 23);
            this.button3.TabIndex = 25;
            this.button3.Text = "New Order";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MarioandLuigiV2.Properties.Resources.maaa;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(654, 392);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tbCart);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.cbChicken);
            this.Controls.Add(this.cbExrtamushrooms);
            this.Controls.Add(this.cbExtracheese);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbFood);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Pizza order";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbFood;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rbnDineIn;
        private System.Windows.Forms.RadioButton rbnTakeAway;
        private System.Windows.Forms.RadioButton rbnSmall;
        private System.Windows.Forms.RadioButton rbnMedium;
        private System.Windows.Forms.RadioButton rbnLarge;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cbExtracheese;
        private System.Windows.Forms.CheckBox cbExrtamushrooms;
        private System.Windows.Forms.CheckBox cbChicken;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timerListBox;
        private System.Windows.Forms.ListBox tbCart;
        private System.Windows.Forms.Button button3;
    }
}

